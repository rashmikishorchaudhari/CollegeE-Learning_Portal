package com.app.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.app.Services.AssignClassService;
import com.app.Services.CourseService;
import com.app.Services.FacultyService;
import com.app.Services.FileStorageService;
import com.app.Services.MessageService;
import com.app.Services.StudentService;
import com.app.Services.SubjectService;

import com.app.dto.AssignClassDTO;
import com.app.dto.DepartmentDTO;
import com.app.dto.ResponseDTO;
import com.app.dto.SignUpRequestForFaculty;
import com.app.dto.SignUpRequestForStudent;
import com.app.message.ResponseFile;
import com.app.message.ResponseMessage;
import com.app.pojo.AssignClass;
import com.app.pojo.Course;
import com.app.pojo.Department;
import com.app.pojo.Faculty;
import com.app.pojo.FileDB;
import com.app.pojo.Message;
import com.app.pojo.Subject;


@RestController
@RequestMapping("/faculty")
@CrossOrigin(origins = "http://localhost:3000")
public class FacultyController {
	
	@Autowired
	private FacultyService facultyService;
	@Autowired
	private CourseService courseService;
	@Autowired
	private SubjectService subjectService;
	@Autowired
	private StudentService studentService;
	@Autowired
	private AssignClassService assignClassService;
	@Autowired
	private MessageService messageService;
	@Autowired
	private FileStorageService storageService;
	
	// add end point for student registration
			@PostMapping("/signup")
			//@RequestBody Faculty request
			public ResponseEntity<?> FacultyRegistration(@RequestBody SignUpRequestForFaculty request) {
				System.out.println("in faculty reg " + request);
				return ResponseEntity.ok(facultyService.registerFaculty(request));
			}
	//Getall Listing
	
					// REST request handling method for listing all courses
					@GetMapping("/courses")
					public ResponseEntity<?> getAllCourses() {
						System.out.println("in get all courses");
						return ResponseEntity.ok(new ResponseDTO<>(courseService.getAllCourses()));
					}
					
					// REST request handling method for listing all subjects
					@GetMapping("/subjects")
					public ResponseEntity<?> getAllSubjects() {
						System.out.println("in get all subjects");
						return ResponseEntity.ok(new ResponseDTO<>(subjectService.getAllSubjects()));
					}
					
					// REST request handling method for listing all students
						@GetMapping("/students")
						public ResponseEntity<?> getAllStudents() {
							System.out.println("in get all students");
							return ResponseEntity.ok(new ResponseDTO<>(studentService.getAllStudents()));
						}
	
	//share documents
						@PostMapping("/upload")
						public ResponseEntity<ResponseMessage> uploadFile(@RequestParam("file") MultipartFile file) {
							String message = "";
							try {
								storageService.store(file);

								message = "Uploaded the file successfully: " + file.getOriginalFilename();
								return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
							} catch (Exception e) {
								message = "Could not upload the file: " + file.getOriginalFilename() + "!";
								return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
							}
						}

						@GetMapping("/files")
						public ResponseEntity<List<ResponseFile>> getListFiles() {
							System.out.println("in list files");
							List<ResponseFile> files = storageService.getAllFiles().map(dbFile -> {
								String fileDownloadUrl = ServletUriComponentsBuilder.fromCurrentContextPath() // Prepares a URL from the
																												// host, port, scheme, and
										// context path of the given HttpServletRequest.eg : http://localhost:8080/
										.path("/files/")// apends the resource name eg : http://localhost:8080/files
										.path(dbFile.getId().toString()) // appends file id(resource id) http://localhost:8080/files/1
										.toUriString();
								System.out.println("url " + fileDownloadUrl);

								return new ResponseFile(dbFile.getName(), fileDownloadUrl, dbFile.getType(), dbFile.getData().length);
							}).collect(Collectors.toList());

							return ResponseEntity.status(HttpStatus.OK).body(files);
						}

						@GetMapping("/files/{id}")
						public ResponseEntity<byte[]> getFile(@PathVariable Integer id) {
							System.out.println("in get file");
							FileDB fileDB = storageService.getFile(id);

							return ResponseEntity.ok()
									.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileDB.getName() + "\"")
									.body(fileDB.getData());
						}

			
			
	//updateStatus
			// Add REST request handling method to update status in assignClass
			@PutMapping("/assign_class/{assignClassId}")
			public ResponseEntity<?> updateAssignClassbyfaculty(@PathVariable long assignClassId, @RequestBody AssignClassDTO assignClassDTO) {
				System.out.println("in rest : update AssignClassStatus " + assignClassId + " " + assignClassDTO);
				return ResponseEntity.ok(assignClassService.updateAssignClass(assignClassId, assignClassDTO));
			}
			
	//message
			
			// REST request handling method to add a new Message
			@PostMapping("/message")
			public ResponseEntity<?> addMessage(@RequestBody Message message) {
				System.out.println("in add message " + message);
				return ResponseEntity.ok(new ResponseDTO<>(messageService.addMessage(message)));
			}
			
			// REST request handling method for listing all departments
			@GetMapping("/message")
			public ResponseEntity<?> getAllMessages() {
				System.out.println("in get all messages");
				return ResponseEntity.ok(new ResponseDTO<>(messageService.getAllMessage()));
			}
			
			// REST request handling method to delete admin details
			@DeleteMapping("/message/{messageId}")
			public ResponseEntity<?> deleteMessagedetails(@PathVariable long messageId) {
				System.out.println("in del message dtls " + messageId);
				try {
					return ResponseEntity.ok(new ResponseDTO<>(messageService.deleteMessagedetails(messageId)));
				} catch (RuntimeException e) {
					System.out.println("err in delete " + e);
					return new ResponseEntity<>(new ResponseDTO<>("Message details deletion failed"),
							HttpStatus.INTERNAL_SERVER_ERROR);
				}
			}
		
	
}
