package com.app.Services;

import java.util.List;
import java.util.Optional;

import com.app.dto.AssignClassDTO;
import com.app.pojo.AssignClass;


public interface AssignClassService {
	
	public List<AssignClassDTO>getAllAssignClasses();
	AssignClassDTO addAssignClass(AssignClass assignClass);
	String deleteAssignClass(long  assignClassId);
	AssignClassDTO getAssignClass(long  assignClassId);
	AssignClassDTO updateAssignClass(long  assignClassId,AssignClassDTO  assignClassDTO);
	AssignClassDTO updateAssignClassbyfaculty(long assignClassId, AssignClassDTO assignClassDTO);


}
