import React, { Fragment, useEffect, useState, Component } from "react";
import { Link } from "react-router-dom";
import { ListGroup } from "reactstrap";

class faculty_menu extends Component {
    render() {
        return (
            <ListGroup>
            <Link className="text-center list-group-item list-group-item-action" to="/faculty/share_files" action>Share Documents</Link>
            <Link className="text-center list-group-item list-group-item-action" to="/faculty/share_media" action>Share Media</Link>
            <Link className="text-center list-group-item list-group-item-action" to="/faculty/update_status" action>Syllabus Status</Link>
            <Link className="text-center list-group-item list-group-item-action" to="/faculty/shedule_exams" action>Shedule Exams</Link>

        </ListGroup>
        );
    }
}

export default faculty_menu;
    