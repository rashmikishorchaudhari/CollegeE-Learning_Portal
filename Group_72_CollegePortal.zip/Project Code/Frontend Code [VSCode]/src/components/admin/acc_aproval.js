import React, { Fragment, useEffect, useState,Component  } from "react";
import {Form, FormGroup, Label, Input, Container, Button, Col, Row, Table } from 'reactstrap';
import accountService from "../../services/acc_approve";

class acc_aproval extends Component {

    constructor(props) {
        super(props);

        this.state = {
                acc_aprovals:[]
        }

    }

    
    //TO GET ALL ACCOUNTS:-  
    componentDidMount() {
        accountService.getAccounts().then((res) => {
            this.setState({acc_aprovals: res.data});
        })
     }

    render() {
        return (
            <Fragment>
            <Row>
                <Col md="1">
                </Col>
                <Col className="m-3" md="8">
                    <Form>
                        <h3 className="bg-info p-2" style={{ color: "white" }}>New Registered Accounts</h3>
                        <Row Form>
                            <Col md={3}>
                                <FormGroup>
                                    <Label>
                                        Select Department
                            </Label>
                                    <Input type="select" name="department" id="">
                                        <option>Diploma</option>
                                        <option>Engineering</option>
                                        <option>Management</option>
                                        <option>Computer</option>
                                        <option>11th / 12th</option>
                                    </Input>
                                </FormGroup>
                            </Col>
                            <Col md={3}>
                                <FormGroup>
                                    <Label>
                                        Select Course
                            </Label>
                                    <Input type="select" name="course" id="">
                                        <option>MBA</option>
                                        <option>MCA</option>
                                    </Input>
                                </FormGroup>
                            </Col>

                            <Col md={1}>
                                <Container className="text-center mt-4 p-1" >
                                    <Button type="submit" color="outline-info">Search</Button>

                                </Container>
                            </Col>
                        </Row>

                        <Table className="text-center" responsive striped hover bordered size="sm">
                            <thead>
                                <tr>
                                  
                                    <th className="pb-2">Name</th>
                                    <th className="pb-2">Department</th>
                                    <th className="pb-2">Course</th>
                                    <th><Button type="submit" color="success">Approve</Button></th>
                                    <th><Button type="submit" color="danger">Reject</Button></th>


                                </tr>
                            </thead>
                            <tbody>
                            {
                                    this.state.acc_aprovals.map(
                                        account =>
                                            <tr key={account.student_id}>
                                                <td>{account.student_name}</td>
                                                <td>{account.d_id}</td>
                                                <td>{account.c_id}</td>
                                             
                                            </tr>

                                    )
                                }

                            </tbody>
                        </Table>

                    </Form>
                </Col>
            </Row>
        </Fragment>
        );
    }
}

export default acc_aproval;
  