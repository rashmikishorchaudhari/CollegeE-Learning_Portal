package com.app.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.app.Services.CourseService;
import com.app.Services.DepartmentService;
import com.app.Services.FileStorageService;
import com.app.Services.MessageService;
import com.app.Services.StudentService;
import com.app.Services.SubjectService;
import com.app.dto.ResponseDTO;
import com.app.dto.SignUpRequest;
import com.app.dto.SignUpRequestForStudent;
import com.app.dto.StudentDTO;
import com.app.message.ResponseFile;
import com.app.message.ResponseMessage;
import com.app.pojo.FileDB;
import com.app.pojo.Student;


@RestController
@RequestMapping("/student")
@CrossOrigin(origins = "http://localhost:3000")
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	@Autowired
	private  DepartmentService departmentService;
	@Autowired
	private  CourseService courseService;
	@Autowired
	private  SubjectService subjectService;
	@Autowired
	private MessageService messageService;
	@Autowired
	private FileStorageService storageService;
	
	// add end point for student registration
		@PostMapping("/signup")
		public ResponseEntity<?> studentRegistration(@RequestBody SignUpRequestForStudent request) {
			System.out.println("in student reg " + request);
			return ResponseEntity.ok(studentService.registerStudent(request));
		}
	
	// REST request handling method for listing all students
	@GetMapping("/students")
	public ResponseEntity<?> getAllStudents() {
		System.out.println("in get all students");
		return ResponseEntity.ok(new ResponseDTO<>(studentService.getAllStudents()));
	}
	
	 //REST request handling method to add a new student
	@PostMapping("/students")
	public ResponseEntity<?> addStudent(@RequestBody Student student) {
		System.out.println("in add student details " + student);
		return ResponseEntity.ok(new ResponseDTO<>(studentService.addStudent(student)));
	}
//	@PostMapping("/students")
//	public Student addStudent(@RequestBody Student student)
//	{
//		return this.studentService.addStudent(student);
//	}

	// REST request handling method to delete student details
	@DeleteMapping("/students/{studentId}")
	public ResponseEntity<?> deleteStudent(@PathVariable long studentId) {
		System.out.println("in del student dtls " + studentId);
		try {
			return ResponseEntity.ok(new ResponseDTO<>(studentService.deleteStudent(studentId)));
		} catch (RuntimeException e) {
			System.out.println("err in delete " + e);
			return new ResponseEntity<>(new ResponseDTO<>("Student details deletion failed"),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// Add REST request handling method to get studentdetails
	@GetMapping("/students/{studentId}")
	public ResponseEntity<?> getStudent(@PathVariable long studentId) {
		System.out.println("in get student dtls " + studentId);
		return ResponseEntity.ok(new ResponseDTO<>(studentService.getStudent(studentId)));
	}

	// Add REST request handling method to update student details
	@PutMapping("/students/{studentId}")
	public ResponseEntity<?> updateStudent(@PathVariable long studentId, @RequestBody StudentDTO studentDTO) {
		System.out.println("in rest : update details " +studentId + " " + studentDTO);
		return ResponseEntity.ok(studentService.updateStudent(studentId, studentDTO));
	}
	
    
	
	//Message
	// REST request handling method for listing all departments
				@GetMapping("/message")
				public ResponseEntity<?> getAllMessages() {
					System.out.println("in get all messages");
					return ResponseEntity.ok(new ResponseDTO<>(messageService.getAllMessage()));
				}
	//upload documents
				@PostMapping("/upload")
				public ResponseEntity<ResponseMessage> uploadFile(@RequestParam("file") MultipartFile file) {
					String message = "";
					try {
						storageService.store(file);

						message = "Uploaded the file successfully: " + file.getOriginalFilename();
						return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
					} catch (Exception e) {
						message = "Could not upload the file: " + file.getOriginalFilename() + "!";
						return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
					}
				}

				@GetMapping("/files")
				public ResponseEntity<List<ResponseFile>> getListFiles() {
					System.out.println("in list files");
					List<ResponseFile> files = storageService.getAllFiles().map(dbFile -> {
						String fileDownloadUrl = ServletUriComponentsBuilder.fromCurrentContextPath() // Prepares a URL from the
																										// host, port, scheme, and
								// context path of the given HttpServletRequest.eg : http://localhost:8080/
								.path("/files/")// apends the resource name eg : http://localhost:8080/files
								.path(dbFile.getId().toString()) // appends file id(resource id) http://localhost:8080/files/1
								.toUriString();
						System.out.println("url " + fileDownloadUrl);

						return new ResponseFile(dbFile.getName(), fileDownloadUrl, dbFile.getType(), dbFile.getData().length);
					}).collect(Collectors.toList());

					return ResponseEntity.status(HttpStatus.OK).body(files);
				}

				@GetMapping("/files/{id}")
				public ResponseEntity<byte[]> getFile(@PathVariable Integer id) {
					System.out.println("in get file");
					FileDB fileDB = storageService.getFile(id);

					return ResponseEntity.ok()
							.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileDB.getName() + "\"")
							.body(fileDB.getData());
				}

	
	
}
