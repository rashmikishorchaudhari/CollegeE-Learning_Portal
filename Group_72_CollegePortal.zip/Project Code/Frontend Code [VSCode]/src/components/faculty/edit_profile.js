import React, { Fragment, useEffect, useState,Component } from "react";
import { Link } from "react-router-dom";
import { Form, FormGroup, Label, Input, Container, Button, Col, Row, Table } from "reactstrap";

class edit_profile extends Component {
    constructor(props) {
        super(props);

        this.state = {
        
        }

    }
    render() {
        return (
            <Fragment>
            <Row>
                <Col md="2">
                </Col>
                <Col className="m-3" md="6">
                    <Form>
                        <h3 className="bg-info p-2 text-center" style={{ color: "white" }}>Faculty Registration</h3>
                        <Row form>
                            <Col md={6}>
                                <FormGroup>
                                    <Label for="">Department</Label>
                                    <Input type="select" name="department" id="" disabled>
                                        <option>MBA</option>
                                    </Input>
                                </FormGroup>
                            </Col>
                            <Col md={6}>
                                <FormGroup>
                                    <Label for="">Name</Label>
                                    <Input type="text" name="name" id="" placeholder="Enter Full Name" />
                                </FormGroup>
                            </Col>
                        </Row>
                        <Row form>
                            <Col md={6}>
                                <FormGroup>
                                    <Label for="">Contact No</Label>
                                    <Input type="number" name="contact" id="" placeholder="Enter Mobile Number" />
                                </FormGroup>
                            </Col>
                            <Col md={6}>
                                <FormGroup>
                                    <Label for="">Email-Address</Label>
                                    <Input type="email" name="email_ad" id="" placeholder="Enter Personal Email address" />
                                </FormGroup>
                            </Col>
                        </Row>
                        <Row form>

                            <Col md={12}>
                                <FormGroup>
                                    <Label for="">Specialization in</Label>
                                    <Input type="textarea" name="specialized" id="" placeholder="Enter Details" />
                                </FormGroup>
                            </Col>
                        </Row>
                        <Row form>
                            <Col md={3}>
                            </Col>
                            <Col md={6}>
                                <FormGroup>
                                    <Label for="">Change Username</Label>
                                    <Input type="email" name="username" id="" placeholder="Enter Username" />
                                </FormGroup>
                            </Col>
                        </Row>


                        <Container className="text-center" >
                            <Button type="submit" color="success">Update</Button>
                            <Button type="reset" color="danger ml-2">Reset</Button>
                        </Container>
                    </Form>
                </Col>
            </Row>


        </Fragment>
        );
    }
}

export default edit_profile;
 