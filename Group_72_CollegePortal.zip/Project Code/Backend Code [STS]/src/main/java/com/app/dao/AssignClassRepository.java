package com.app.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.pojo.AssignClass;
@Repository
public interface AssignClassRepository extends JpaRepository<AssignClass, Long> {

	AssignClass save(long assignClassId);

	Optional<AssignClass> findById(long assignClassId) ;

}
