package com.app.pojo;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "departments")
public class Department {
	 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="dept_id")
	private long deptId;
	@Column(name="dept_name",length = 50)
	private String name;
	
	@OneToMany(mappedBy = "chosenDepartment",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<Course> courses;
	
	@OneToMany(mappedBy = "chosenDepartment",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<Faculty> faculty;
	
	@OneToMany(mappedBy = "chosenDepartment",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<Student>students;
	
	@OneToMany(mappedBy = "chosenDepartment",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<AssignClass>assignclass;
	
	@OneToMany(mappedBy = "chosenDepartment",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<Subject>subject;
	
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Department(long deptId, String name, List<Course> courses, List<Faculty> faculty, List<Student> students,
			List<AssignClass> assignclass, List<Subject> subject) {
		super();
		this.deptId = deptId;
		this.name = name;
		this.courses = courses;
		this.faculty = faculty;
		this.students = students;
		this.assignclass = assignclass;
		this.subject = subject;
	}

	/**
	 * @return the deptId
	 */
	public long getDeptId() {
		return deptId;
	}
	/**
	 * @param deptId the deptId to set
	 */
	public void setDeptId(long deptId) {
		this.deptId = deptId;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/** 
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the courses
	 */
	public List<Course> getCourses() {
		return courses;
	}
	/**
	 * @param courses the courses to set
	 */
	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}
	/**
	 * @return the faculty
	 */
	public List<Faculty> getFaculty() {
		return faculty;
	}
	/**
	 * @param faculty the faculty to set
	 */
	public void setFaculty(List<Faculty> faculty) {
		this.faculty = faculty;
	}
	/**
	 * @return the students
	 */
	public List<Student> getStudents() {
		return students;
	}
	/**
	 * @param students the students to set
	 */
	public void setStudents(List<Student> students) {
		this.students = students;
	}
	/**
	 * @return the assignclass
	 */
	public List<AssignClass> getAssignclass() {
		return assignclass;
	}
	/**
	 * @param assignclass the assignclass to set
	 */
	public void setAssignclass(List<AssignClass> assignclass) {
		this.assignclass = assignclass;
	}
	
	/**
	 * @return the subject
	 */
	public List<Subject> getSubject() {
		return subject;
	}
	/**
	 * @param subject the subject to set
	 */
	public void setSubject(List<Subject> subject) {
		this.subject = subject;
	}
	@Override
	public String toString() {
		return "Department [deptId=" + deptId + ", name=" + name + "]";
	}
	
	//helper methods to add n remove student
			public void addStudent(Student s)
			{
				students.add(s);
				s.setChosenDepartment(this);
			}
			public void removeStudent(Student s)
			{
				students.remove(s);
				s.setChosenDepartment(this);
			}
			
			//helper methods to add n remove faculty
					public void addFaculty(Faculty f)
					{
						faculty.add(f);
						f.setChosenDepartment(this);
					}
					public void removeFaculty(Faculty f)
					{
						faculty.remove(f);
						f.setChosenDepartment(this);
					}
										
					//helper methods to add n remove assignclass
					public void addAssignClass(AssignClass as)
					{
						assignclass.add(as);
						as.setChosenDepartment(this);
					}
					public void removeAssignClass(AssignClass as)
					{
						assignclass.remove(as);
						as.setChosenDepartment(this);
					}
					
					//helper methods to add n remove subject
					public void addSubject(Subject sub)
					{
						subject.add(sub);
						sub.setChosenDepartment(this);
					}
					public void removeSubject(Subject sub)
					{
						subject.remove(sub);
						sub.setChosenDepartment(null);
					}
					
					//helper methods to add n remove course
					public void addCourse(Course c)
					{
						courses.add(c);
						c.setChosenDepartment(this);
					}
					public void removeCourse(Course c)
					{
						courses.remove(c);
						c.setChosenDepartment(null);
					}
					
}
