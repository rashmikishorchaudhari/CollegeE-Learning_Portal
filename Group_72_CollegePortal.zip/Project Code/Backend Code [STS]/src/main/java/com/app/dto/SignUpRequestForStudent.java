package com.app.dto;

import java.util.HashSet;
import java.util.Set;

import com.app.pojo.Department;

public class SignUpRequestForStudent {
	private String name,email, password;
	//private long id;
	//private String name;
	private String address;
	private String contactno;
	private long d_id;
	private long c_id;
	private Set<String> roles=new HashSet<>();
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getContactno() {
		return contactno;
	}
	public void setContactno(String contactno) {
		this.contactno = contactno;
	}
	
	public long getD_id() {
		return d_id;
	}
	public void setD_id(long d_id) {
		this.d_id = d_id;
	}
	public long getC_id() {
		return c_id;
	}
	public void setC_id(long c_id) {
		this.c_id = c_id;
	}
	public Set<String> getRoles() {
		return roles;
	}
	public void setRoles(Set<String> roles) {
		this.roles = roles;
	}
	@Override
	public String toString() {
		return "SignUpRequestForStudent [name=" + name + ", email=" + email + ", password=" + password + ", address="
				+ address + ", contactno=" + contactno + ", d_id=" + d_id + ", c_id=" + c_id + ", roles=" + roles + "]";
	}

	


	




		

}
