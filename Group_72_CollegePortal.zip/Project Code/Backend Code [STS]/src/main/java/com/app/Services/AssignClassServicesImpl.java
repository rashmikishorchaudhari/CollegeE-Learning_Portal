package com.app.Services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.custom_exc.ResourceNotFoundException;
import com.app.dao.AssignClassRepository;
import com.app.dto.AdminDTO;
import com.app.dto.AssignClassDTO;
import com.app.dto.FacultyDTO;
import com.app.pojo.Admin;
import com.app.pojo.AssignClass;
import com.app.pojo.Faculty;
import com.app.pojo.Subject;

@Service
@Transactional
public class AssignClassServicesImpl implements  AssignClassService {
	
	@Autowired
	private AssignClassRepository assignclassRepo;
	
	
	
	public AssignClassServicesImpl() {}

	@Override
	public List<AssignClassDTO> getAllAssignClasses() {
		List<AssignClassDTO> list = new ArrayList<>();
		assignclassRepo.findAll().forEach(as -> {
			AssignClassDTO dto = new AssignClassDTO();
			BeanUtils.copyProperties(as, dto);
			list.add(dto);
		});
		return list;
	}

	
	
	
	@Override
	public AssignClassDTO addAssignClass(AssignClass assignClass) {
		// invoke dao's method for persistence
		AssignClass persistentAssignClass = assignclassRepo.save(assignClass);
		// for sending response copy persistent user details ---> user dto(so that you
		// can control what all to share with the front end)
		AssignClassDTO dto = new AssignClassDTO();
		BeanUtils.copyProperties(persistentAssignClass, dto);
		return dto;
	}// rets a dto  to the caller.

	

	@Override
	public String deleteAssignClass(long assignClassId) {
		//below method rets persistent user of exists or throws exc
		AssignClass assignClass = assignclassRepo.findById(assignClassId).orElseThrow(() -> new ResourceNotFoundException("Invalid AssignClass ID"));
		assignclassRepo.deleteById(assignClassId);
		return "AssignClass details for ID "+assignClassId+" deleted...";

	}

	@Override
	public AssignClassDTO getAssignClass(long assignClassId) {
		AssignClass assignClass = assignclassRepo.findById(assignClassId).orElseThrow(() -> new ResourceNotFoundException("InvalidassignClass ID"));
		AssignClassDTO assignClassDTO = new AssignClassDTO();
		BeanUtils.copyProperties(assignClass,assignClassDTO);
		System.out.println("assignClass" + assignClass);
		System.out.println("assignClass DTO  " + assignClassDTO);
		return assignClassDTO;
	}

	@Override
	public AssignClassDTO updateAssignClass(long assignClassId, AssignClassDTO assignClassDTO) {
		System.out.println("in update " + assignClassDTO);
		// fetch exsiting details from the db
		AssignClass assignClassdetails= assignclassRepo.findById(assignClassId).get();
		System.out.println("assignClass from db " + assignClassdetails);
		// => userDetails : PERSISTENT POJO
		// copy updated user details coming from request payload ---> User details
		BeanUtils.copyProperties(assignClassDTO, assignClassdetails);
		assignClassdetails.setId(assignClassId);
		assignClassDTO.setId(assignClassId);
		System.out.println("updated assignClass dtls " + assignClassdetails);
		// modified state of persistent POJO
		return assignClassDTO;
	}

	@Override
	public AssignClassDTO updateAssignClassbyfaculty(long assignClassId, AssignClassDTO assignClassDTO) {
		System.out.println("in update " + assignClassDTO);
		// fetch exsiting details from the db
		AssignClass assignClassdetails=assignclassRepo.findById(assignClassId).get();
		System.out.println("assignClass from db " + assignClassdetails);
		// => userDetails : PERSISTENT POJO
		// copy updated user details coming from request payload ---> User details
		BeanUtils.copyProperties(assignClassDTO, assignClassdetails,"Totalnoofunits");
		assignClassdetails.setId(assignClassId);
		assignClassDTO.setId(assignClassId);
		System.out.println("updated assignClass dtls " + assignClassdetails);
		// modified state of persistent POJO
		assignclassRepo.save(assignClassId);
		return assignClassDTO;
	}

	
	}



