import axios from "axios";

const COURSE_BASE_URL = "http://localhost:7070/admin/courses";
class courseService {
    getCourses() {
        return axios.get(COURSE_BASE_URL);
    }

    createCourse(cours) {
        return axios.post(COURSE_BASE_URL, cours);
    }

    getCourseByID(coursID) {
        return axios.get(COURSE_BASE_URL + '/' + coursID);
    }

    updateCourseByID(cours, coursID) {
        return axios.put(COURSE_BASE_URL + '/' + coursID, cours);
    }

    deleteCourseByID(coursID) {
        return axios.delete(COURSE_BASE_URL + '/' + coursID);
    }
}

export default new courseService;