package com.app.pojo;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="attendance")
public class Attendance {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long Id;
	private LocalDate Date;
	private String Attendance;
	
	@ManyToOne
	@JoinColumn(name="d_id",nullable=false,insertable = false,updatable = false)
	private Department chosenDepartment;
	
	@ManyToOne
	@JoinColumn(name="c_id",nullable=false)
	private Course chosenCourse;
	
	@ManyToOne
	@JoinColumn(name="sub_id",nullable=false)
	private Subject chosenSubject;
	
	@ManyToOne
	@JoinColumn(name="d_id",nullable=false)
	private Student students;

	public Attendance() {
		super();
		// TODO Auto-generated constructor stub
	}



	
	
	public Attendance(Long id, LocalDate date, String attendance, Department chosenDepartment, Course chosenCourse,
			Subject chosenSubject, Student students) {
		super();
		Id = id;
		Date = date;
		Attendance = attendance;
		this.chosenDepartment = chosenDepartment;
		this.chosenCourse = chosenCourse;
		this.chosenSubject = chosenSubject;
		this.students = students;
	}

	
	public Long getId() {
		return Id;
	}





	public void setId(Long id) {
		Id = id;
	}





	public LocalDate getDate() {
		return Date;
	}





	public void setDate(LocalDate date) {
		Date = date;
	}





	public String getAttendance() {
		return Attendance;
	}





	public void setAttendance(String attendance) {
		Attendance = attendance;
	}





	public Department getChosenDepartment() {
		return chosenDepartment;
	}





	public void setChosenDepartment(Department chosenDepartment) {
		this.chosenDepartment = chosenDepartment;
	}





	public Course getChosenCourse() {
		return chosenCourse;
	}





	public void setChosenCourse(Course chosenCourse) {
		this.chosenCourse = chosenCourse;
	}





	public Subject getChosenSubject() {
		return chosenSubject;
	}





	public void setChosenSubject(Subject chosenSubject) {
		this.chosenSubject = chosenSubject;
	}





	public Student getStudents() {
		return students;
	}





	public void setStudents(Student students) {
		this.students = students;
	}





	@Override
	public String toString() {
		return "Attendance [Id=" + Id + ", Date=" + Date + ", Attendance=" + Attendance + ", chosenDepartment="
				+ chosenDepartment + ", chosenCourse=" + chosenCourse + ", chosenSubject=" + chosenSubject
				+ ", students=" + students + "]";
	}
	
	

	
	
}
