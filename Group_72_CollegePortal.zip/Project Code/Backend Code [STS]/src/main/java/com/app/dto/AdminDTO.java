package com.app.dto;


public class AdminDTO {
	
	private long id;
	private String name;
	private String instituteName;
	private String email;
	private String contactNo;	
	private  String adharNo;
	private  String userName;
	public AdminDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AdminDTO(long id, String name, String institutename, String email, String contactno, String adharno,
			String username) {
		super();
		this.id = id;
		this.name = name;
		this.instituteName = institutename;
		this.email = email;
		this.contactNo = contactno;
		this.adharNo = adharno;
		this.userName = username;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getInstituteName() {
		return instituteName;
	}
	public void setInstituteName(String instituteName) {
		this.instituteName = instituteName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getAdharNo() {
		return adharNo;
	}
	public void setAdharNo(String adharNo) {
		this.adharNo = adharNo;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	@Override
	public String toString() {
		return "AdminDTO [id=" + id + ", name=" + name + ", instituteName=" + instituteName + ", email=" + email
				+ ", contactNo=" + contactNo + ", adharNo=" + adharNo + ", userName=" + userName + "]";
	}
	
	

}
