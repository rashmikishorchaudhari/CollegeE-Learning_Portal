package com.app.dto;

public class AssignClassDTO {

	private long id;
	private int Status;
	public AssignClassDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AssignClassDTO(long id, int status) {
		super();
		this.id = id;
		Status = status;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public int getStatus() {
		return Status;
	}
	public void setStatus(int status) {
		Status = status;
	}
	@Override
	public String toString() {
		return "AssignClassDTO [id=" + id + ", Status=" + Status + "]";
	}
	
	
}
