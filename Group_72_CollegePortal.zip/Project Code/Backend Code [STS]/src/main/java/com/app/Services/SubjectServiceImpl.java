package com.app.Services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.custom_exc.ResourceNotFoundException;
import com.app.dao.StudentRepository;
import com.app.dao.SubjectRepository;
import com.app.dto.AdminDTO;
import com.app.dto.DepartmentDTO;
import com.app.dto.SubjectDTO;
import com.app.pojo.Admin;
import com.app.pojo.AssignClass;
import com.app.pojo.Department;
import com.app.pojo.Faculty;
import com.app.pojo.Student;
import com.app.pojo.Subject;

@Service
@Transactional
public class SubjectServiceImpl implements SubjectService {
	

	@Autowired
	private SubjectRepository subjectRepo;
	
	public SubjectServiceImpl() {}
	
	@Override
	public List<SubjectDTO> getAllSubjects() {
		List<SubjectDTO> list = new ArrayList<>();
		subjectRepo.findAll().forEach(sub -> {
			SubjectDTO dto = new SubjectDTO();
			BeanUtils.copyProperties(sub, dto);
			list.add(dto);
		});
		return list;
	}
	
	@Override
	public SubjectDTO addSubject(Subject subject) {
		// invoke dao's method for persistence
		 Subject persistentSubject = subjectRepo.save(subject);
		// for sending response copy persistent user details ---> user dto(so that you
		// can control what all to share with the front end)
		SubjectDTO dto = new SubjectDTO();
		BeanUtils.copyProperties(persistentSubject, dto);
		return dto;
	}// rets a dto  to the caller.

	

	@Override
	public String deleteSubject(long subjectId) {
		//below method rets persistent user of exists or throws exc
		Subject subject = subjectRepo.findById(subjectId).orElseThrow(() -> new ResourceNotFoundException("Invalid Subject ID"));
		subjectRepo.deleteById(subjectId);
		return "Subject details for ID "+subjectId+" deleted...";

	}

	@Override
	public SubjectDTO getSubject(long subjectId) {
		Subject subject = subjectRepo.findById(subjectId).orElseThrow(() -> new ResourceNotFoundException("Invalid Subject ID"));
		SubjectDTO subjectDTO = new SubjectDTO();
		BeanUtils.copyProperties(subject, subjectDTO);
		System.out.println("subject" + subject);
		System.out.println("subject DTO  " +subjectDTO);
		return subjectDTO;
	}

	@Override
	public SubjectDTO updateSubject(long subjectId, SubjectDTO subjectDTO) {
		System.out.println("in update " + subjectDTO);
		// fetch exsiting details from the db
		Subject subjectdetails = subjectRepo.findById(subjectId).get();
		System.out.println("subject from db " + subjectdetails);
		// => userDetails : PERSISTENT POJO
		// copy updated user details coming from request payload ---> User details
		BeanUtils.copyProperties(subjectDTO, subjectdetails);
		subjectdetails.setId(subjectId);
		subjectDTO.setId(subjectId);
		System.out.println("updated department dtls " + subjectdetails);
		// modified state of persistent POJO
		return subjectDTO;
	}

	
	
	

}
