package com.app.dto;

public class SubjectDTO {

	private long id;
	private String name;
	private int units;
	private String courseName;
	private String departmentName;
	
	public SubjectDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
//	public SubjectDTO(long id, String name, int units) {
//		super();
//		this.id = id;
//		this.name = name;
//		this.units = units;
//	}
	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the units
	 */
	public int getUnits() {
		return units;
	}
	/**
	 * @param units the units to set
	 */
	public void setUnits(int units) {
		this.units = units;
	}
	
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	@Override
	public String toString() {
		return "SubjectDTO [id=" + id + ", name=" + name + ", units=" + units + ", courseName=" + courseName + "]";
	}
	
	
}
