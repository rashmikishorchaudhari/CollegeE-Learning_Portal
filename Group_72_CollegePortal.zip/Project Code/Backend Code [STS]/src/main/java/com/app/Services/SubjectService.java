package com.app.Services;

import java.util.List;
import java.util.Optional;

import com.app.dto.SubjectDTO;
import com.app.pojo.AssignClass;
import com.app.pojo.Department;
import com.app.pojo.Subject;

public interface SubjectService {
		
public List<SubjectDTO>getAllSubjects();
SubjectDTO addSubject(Subject subject);
String deleteSubject(long  subjectId);
SubjectDTO getSubject(long  subjectId);
SubjectDTO updateSubject(long  subjectId,SubjectDTO  subjectDTO);

}
