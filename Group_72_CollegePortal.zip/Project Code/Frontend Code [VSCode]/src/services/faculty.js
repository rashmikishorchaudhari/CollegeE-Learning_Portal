import axios from "axios";

const FACULTY_BASE_URL="http://localhost:7070/faculty";
class facultyService{
    getFaculties(){
        return axios.get(FACULTY_BASE_URL);
    }
    createFaculty(fac) {
        return axios.post(FACULTY_BASE_URL, fac);
    }

    getFacultyByID(facID) {
        return axios.get(FACULTY_BASE_URL +'/'+ facID);
    }

    updateFacultyByID(fac, facID) {
        return axios.put(FACULTY_BASE_URL +'/'+ facID, fac);
    }

    deleteFacultyByID(facID) {
        return axios.delete(FACULTY_BASE_URL +'/'+ facID);
    }
}

export default new facultyService;