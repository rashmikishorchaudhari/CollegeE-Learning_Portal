package com.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.app.pojo.AssignClass;
import com.app.pojo.Faculty;
import com.app.pojo.Student;
import com.app.pojo.Subject;

@Repository
public interface FacultyRepository extends JpaRepository<Faculty, Long>{
	//@Query("select distinct f from Faculty f join fetch f.roles where f.userName=:nm")
	//Optional<Faculty> findByFacultyName(@Param("nm") String facultyName);

}
