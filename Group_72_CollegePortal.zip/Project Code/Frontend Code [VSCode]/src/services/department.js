import axios from "axios";

const DEPARTMENT_BASE_URL = "http://localhost:7070/admin/departments";
class departmentService {
    getDeparments() {
        return axios.get(DEPARTMENT_BASE_URL);
    }

    createDeparment(dept) {
        return axios.post(DEPARTMENT_BASE_URL, dept);
    }

    getDeparmentByID(deptID) {
        return axios.get(DEPARTMENT_BASE_URL + '/' + deptID);
    }

    updateDeparmentByID(dept, deptID) {
        return axios.put(DEPARTMENT_BASE_URL + '/' + deptID, dept);
    }

    deleteDeparmentByID(deptID) {
        return axios.delete(DEPARTMENT_BASE_URL + '/' + deptID);
    }


}

export default new departmentService;