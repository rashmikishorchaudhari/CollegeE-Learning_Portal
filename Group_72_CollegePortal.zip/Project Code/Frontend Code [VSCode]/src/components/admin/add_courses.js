import React, { Fragment, Component } from "react";
import { Form, FormGroup, Label, Input, Container, Button, Col, Row, Table } from "reactstrap";
import courseService from "../../services/course";
import departmentService from "../../services/department";
import { toast, Flip } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

class add_courses extends Component {
    constructor(props) {
        super(props);

        this.state = {
            //TO GET ID FROM URL (params)
            id: this.props.match.params.id,

            //TO GET ALL DEPT DEATAILS TO DISPLAY
            departments: [],
            // departments: [{deptId:'1',name:'Computer'},
            // {deptId:'2',name:'Management'},
            // {deptId:'3',name:'Diploma'},],

            //TO GET ALL COURSES
            courses: [],
            // courses: [{ courseid: '1', name: 'BCA', deptId: 'Computer', fees: '10000' }],

            //TO GET COURSES DETAILS ONE BY ONE ON FORM
            deptId: '',
            name: '',
            duration: '',
            fees: '',
            pattern: '',
           

        }
        //BINDING ALL THE EVENTS
        //FOR FILEDS
        this.changeDeptNameHandler = this.changeDeptNameHandler.bind(this);
        this.changeCourseNameHandler = this.changeCourseNameHandler.bind(this);
        this.changePatternHandler = this.changePatternHandler.bind(this);
        this.changeDurationHandler = this.changeDurationHandler.bind(this);
        this.changeFeeHandler = this.changeFeeHandler.bind(this);
        //FOR BUTTONS
        this.saveOrUpdateCourse = this.saveOrUpdateCourse.bind(this);
        // this.editCourse = this.editCourse.bind(this);
        this.deleteCourse = this.deleteCourse.bind(this);

    }

    // //TO GET ALL DEPARTMENTS:-  
    // componentWillMount() {
    //     document.title = "Add Department";
    //     departmentService.getDeparments().then((res) => {
    //         this.setState({ departments: res.data.result });
    //     })
    // }

    //TO GET ALL COURSES:-  
    componentWillMount() {
        document.title = "Add Course";
        //TO GET ALL COURSES:- 
        courseService.getCourses().then((res) => {
            this.setState({ courses: res.data.result });
        })
         //TO GET ALL DEPARTMENTS:-
         departmentService.getDeparments().then((res) => {
            console.log("RESPONSE:- ",JSON.stringify(res.data.result));
            this.setState({ departments: res.data.result });
        })
    }

    // //EVENT HANDLER TO FILL THE DATA IN FIELD
    changeDeptNameHandler = (event) => {
        this.setState({ deptId: event.target.value });

    }
    changeCourseNameHandler = (event) => {
        this.setState({ name: event.target.value });

    }
    changePatternHandler = (event) => {
        this.setState({ pattern: event.target.value });

    }
    changeDurationHandler = (event) => {
        this.setState({ duration: event.target.value });

    }
    changeFeeHandler = (event) => {
        this.setState({ fees: event.target.value });

    }

    //TO SAVE THE FORM DATA
    saveOrUpdateCourse = (e) => {
        e.preventDefault();
        let cours = {
            departmentName: this.state.deptId,
            name: this.state.name,
            pattern: this.state.pattern,
            duration: this.state.duration,
            fees: this.state.fees
        };

        //TO PRINT DATA ON CONSOLE
        console.log('cours =>' + JSON.stringify(cours));

        if (this.state.id > 0) {
            //TO UPDATE THE DATA FROM courseid
            courseService.updateCourseByID(cours, this.state.id).then((res) => {
                this.props.history.push('/admin/add_course');

            })

        } else {
            //TO SAVE/CREATE DATA TO SERVER
            courseService.createCourse(cours).then((res) => {
               
                this.props.history.push('/admin/add_course');
                console.log(JSON.stringify(res.data.result));
                // alert("Course Added SuccessFully");
                toast.success('Course Added SuccessFully...', {
                    position: "top-center",
                    autoClose: 3000,
                    transition: Flip,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: false,
                    draggable: true,
                    progress: undefined,
                  }); 
                
            })

            courseService.getCourses().then((res) => {
                this.setState({ courses: res.data.result });
                console.log(JSON.stringify(res.data.result));
                this.props.history.push('/admin/add_course');
                // alert("Loading Courses...");
                toast.info('Loading Courses...', {
                    position: "top-center",
                    autoClose: 3000,
                    transition: Flip,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: false,
                    draggable: true,
                    progress: undefined,
                  }); 
            })

        }

    }

    //EVENT TO GET COURSE DETAIL BY ID
    editCourse(id) {
        this.props.history.push(`/admin/add_course/${id}`);
    }

    //EVENT TO DELETE COURSE DETAIL BY ID
    deleteCourse(id) {
        courseService.deleteCourseByID(id).then((res) => {
            this.props.history.push('/admin/add_course');
            // alert("Deleted SuccessFully...");
            toast.error('Deleted SuccessFully...', {
                position: "top-center",
                autoClose: 3000,
                transition: Flip,
                hideProgressBar: true,
                closeOnClick: true,
                pauseOnHover: false,
                draggable: true,
                progress: undefined,
              });
            //JUST FILTERING DEPT ARRAY DATA
            this.setState({ courses: this.state.courses.filter(cours => cours.id !== id) });

            courseService.getCourses().then((res) => {
                this.setState({ courses: res.data.result });
                this.props.history.push('/admin/add_course');
                // alert("Loading Courses...");
                toast.info('Loading Courses...', {
                    position: "top-center",
                    autoClose: 3000,
                    transition: Flip,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: false,
                    draggable: true,
                    progress: undefined,
                  });
            })
        })

    }

    // //TO UPDATE FORM DATA FROM COURSE ID
    // componentDidMount() {
    //     if (this.state.id > 0) {
    //         courseService.getCourseByID(this.state.id).then((res) => {
    //             let cours = res.data.result;
    //             this.setState({ deptId: cours.deptId, name: cours.name, pattern: cours.pattern, duration: cours.duration, fees: cours.fees });
    //         })

    //     } else {
    //         return
    //     }

    // }

    cancel() {
        this.props.history.push('/admin');
    }

    getTitle() {
        if (this.state.id > 0) {
            return <h3 className="bg-info p-2 text-center" style={{ color: "white" }}>
                Update Course</h3>

        }
        else {
            return <h3 className="bg-info p-2 text-center" style={{ color: "white" }}>
                New Course</h3>
        }
    }

    render() {
        return (
            <Fragment>
                <Row>
                    <Col md={1}>
                    </Col>
                    <Col className="m-3" md={8}>
                        <Form>

                            {
                                this.getTitle()
                            }
                            <Row form>
                             
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Select Department</Label>
                                        <Input type="select" value={this.state.deptId}
                                            onChange={this.changeDeptNameHandler}>

                                            {
                                                this.state.departments.map(
                                                    department =>
                                                        <option key={department.deptId} >{department.name}</option>
                                                )
                                            }
                                        </Input>
                                      
                                    </FormGroup>
                                </Col>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Name</Label>
                                        <Input type="text" value={this.state.name}
                                            onChange={this.changeCourseNameHandler}
                                            placeholder="Enter Course Duration" />

                                    </FormGroup>
                                </Col>
                            </Row>
                            <Row form>
                                
                                <Col md={6}>
                                    <Label for="">Select Pattern</Label>
                                    <Input type="select" value={this.state.pattern}
                                        onChange={this.changePatternHandler}>
                                        <option value="">--- Select Pattern ---</option>
                                        <option value="yearly">Yearly</option>
                                        <option value="semister">Semister</option>

                                    </Input>
                                   
                                </Col>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Duration in Month</Label>
                                        <Input type="number" value={this.state.duration}
                                            onChange={this.changeDurationHandler}
                                            placeholder="Enter Course Duration" />
                                    </FormGroup>
                                  
                                </Col>
                            </Row>
                            <Row form>
                                <Col md={3}></Col>
                                <Col md={6}>
                                    <FormGroup>
                                        <Label for="">Course Fee</Label>
                                        <Input type="number" value={this.state.fees}
                                            onChange={this.changeFeeHandler}
                                            placeholder="Enter Amount" />
                                    </FormGroup>
                                </Col>
                            </Row>

                            <Container className="text-center" >
                                <Button onClick={this.saveOrUpdateCourse} color="success">Save</Button>
                                <Button onClick={this.cancel.bind(this)} color="danger ml-2">Cancel</Button>
                            </Container>
                        </Form>
                    </Col>
                </Row>

                <Row>
                    <Col md={1}>
                    </Col>
                    <Col className="m-3" md={8}>
                        <Row>
                            <Col>
                                <h3 className="bg-info p-2 text-center" style={{ color: "white" }}>Edit-Details</h3>
                                <Table className="text-center" striped hover bordered size="sm">
                                    <thead>
                                        <tr>

                                            <th>Course Name</th>
                                            {/* <th>Department</th> */}
                                            <th>Pattern</th>
                                            <th>Months</th>
                                            <th>Fees</th>
                                            {/* <th>Edit</th> */}
                                            <th>Delete</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            this.state.courses.map(
                                                course =>
                                                    <tr key={course.courseid}>
                                                        <td>{course.name}</td>
                                                        <td>{course.pattern}</td>
                                                        <td>{course.duration}</td>
                                                        {/* <td>{course.deptId}</td> */}
                                                        <td>{course.fees}</td>
                                                        {/* <td><Button onClick={() => this.editCourse(course.courseid)} color="info">Edit</Button></td> */}
                                                        <td><Button onClick={() => this.deleteCourse(course.courseid)} color="info">Delete</Button></td>

                                                    </tr>

                                            )
                                        }

                                    </tbody>
                                </Table>
                            </Col>
                        </Row>
                    </Col>
                </Row>
            </Fragment>
        );
    }
}

export default add_courses;