package com.app.dto;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;

import com.app.pojo.Role;

public class FacultyDTO {
	
	private long  id;
	private String name;
	private String email;
	private String contactNo;
	private String specialization;
	private String userName;
	private String password;
	private String departmentName;
	private String courseName;
     private boolean active;
	
	private Set<Role> roles = new HashSet<>();
	public FacultyDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public FacultyDTO(long id, String name, String email, String contactNo, String specialization, String userName,
			String password, String departmentName, String courseName, boolean active, Set<Role> roles) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.contactNo = contactNo;
		this.specialization = specialization;
		this.userName = userName;
		this.password = password;
		this.departmentName = departmentName;
		this.courseName = courseName;
		this.active = active;
		this.roles = roles;
	}


	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	
	
	
	public String getContactNo() {
		return contactNo;
	}


	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}


	public String getSpecialization() {
		return specialization;
	}


	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Set<Role> getRoles() {
		return roles;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}

	
	
	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	@Override
	public String toString() {
		return "FacultyDTO [id=" + id + ", name=" + name + ", email=" + email + ", contactNo=" + contactNo
				+ ", specialization=" + specialization + ", userName=" + userName + ", password=" + password
				+ ", departmentName=" + departmentName + ", courseName=" + courseName + ", active=" + active
				+ ", roles=" + roles + "]";
	}


	

	
	
	

}
