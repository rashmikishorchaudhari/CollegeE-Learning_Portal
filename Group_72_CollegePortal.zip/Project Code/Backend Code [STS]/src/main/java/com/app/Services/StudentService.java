package com.app.Services;

import java.util.List;
import java.util.Optional;

import com.app.dto.CourseDTO;
import com.app.dto.FacultyDTO;
import com.app.dto.SignUpRequestForStudent;
import com.app.dto.StudentDTO;
import com.app.dto.UserResponseDTO;
import com.app.pojo.Course;
import com.app.pojo.Student;
import com.app.pojo.StudentDocument;

public interface StudentService {
	
	public List<StudentDTO>getAllStudents();
	StudentDTO addStudent(Student student);
	String deleteStudent(long   studentId);
	StudentDTO getStudent(long   studentId);
	StudentDTO updateStudent(long   studentId, StudentDTO   student);
	//StudentDTO registerStudent(SignUpRequest request);
	StudentDTO registerStudent(SignUpRequestForStudent request);
	//StudentDTO registerStudent(Student request);
	

}
