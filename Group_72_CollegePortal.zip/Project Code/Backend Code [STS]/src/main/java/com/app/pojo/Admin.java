
package com.app.pojo;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Admin")
public class Admin {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Admin_id",nullable=false)
	private long id;
	@Column(name = "Admin_name",length = 50)
	private String name;
	@Column(length = 50)
	private String institute_name;
	@Column(length = 50,nullable = false)
	private String email;
	@Column(name = "Admin_contact_no",length = 10)
	private String contact_no;
	@Column(name = "Admin_adhar_no",unique = true,nullable = false,length = 30)
	private  String adharno;
	@Column(nullable = false,unique = true,length = 30)
	private  String username;
	@Column(nullable = false,length = 20)
	private String password;
	
	
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Admin(long id, String name, String institute_name, String email, String contact_no, String adharno,
		String username, String password) {
	super();
	this.id = id;
	this.name = name;
	this.institute_name = institute_name;
	this.email = email;
	this.contact_no = contact_no;
	this.adharno = adharno;
	this.username = username;
	this.password = password;
}

	
	
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getInstitute_name() {
		return institute_name;
	}

	public void setInstitute_name(String institute_name) {
		this.institute_name = institute_name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContact_no() {
		return contact_no;
	}

	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}

	public String getAdharno() {
		return adharno;
	}

	public void setAdharno(String adharno) {
		this.adharno = adharno;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Admin [id=" + id + ", name=" + name + ", institute_name=" + institute_name + ", email=" + email
				+ ", contact_no=" + contact_no + ", adharno=" + adharno + ", username=" + username + ", password="
				+ password + "]";
	}
	
	

}
