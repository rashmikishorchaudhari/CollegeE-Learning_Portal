package com.app.Services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.app.custom_exc.ResourceNotFoundException;
import com.app.dao.CourseRepository;
import com.app.dto.CourseDTO;
import com.app.pojo.AssignClass;
import com.app.pojo.Course;
import com.app.pojo.Department;
import com.app.pojo.SharedFiles;
import com.app.pojo.Student;
import com.app.pojo.Subject;
import com.app.pojo.User;


@Service
@Transactional
public class CourseServiceImpl implements CourseService {
	//private Course course;
	@Autowired
	private CourseRepository courseRepo;
	
//	public CourseServiceImpl(Course course) {
//		super();
//		this.course = course;
//	}
	
	public CourseServiceImpl() {}
		

	@Override
	public List<CourseDTO> getAllCourses() {
		List<CourseDTO> list = new ArrayList<>();
		courseRepo.findAll().forEach(c -> {
			CourseDTO dto = new CourseDTO();
			BeanUtils.copyProperties(c, dto);
			dto.setDepartmentName(c.getChosenDepartment().getName());
			list.add(dto);
		});
		return list;
	}
//
//	@Override
//	public CourseService loadCourseByCoursename(String courseName) {
//		System.out.println("in load course " + courseName);
//		Course course = courseRepo.findByCourseName(courseName)
//				.orElseThrow(() -> new ResourceNotFoundException("Course Name " + courseName + " not found!!!"));
//		return new CourseServiceImpl(course);
//	}


	@Override
	public CourseDTO addCourse(Course course) {
		// invoke dao's method for persistence
		Course persistentCourse = courseRepo.save(course);
		// for sending response copy persistent user details ---> user dto(so that you
		// can control what all to share with the front end)
		CourseDTO dto = new CourseDTO();
		BeanUtils.copyProperties(persistentCourse, dto);
		return dto;
	}// rets a dto  to the caller.

	

	@Override
	public String deleteCourse(long courseId) {
		//below method rets persistent user of exists or throws exc
		Course course = courseRepo.findById(courseId).orElseThrow(() -> new ResourceNotFoundException("Invalid  Course ID"));
		courseRepo.deleteById(courseId);
		return "Course details for ID "+courseId+" deleted...";

	}

	@Override
	public CourseDTO getCourse(long courseId) {
		 Course  course = courseRepo.findById( courseId).orElseThrow(() -> new ResourceNotFoundException("Invalid Course ID"));
		 CourseDTO  courseDTO = new CourseDTO();
		BeanUtils.copyProperties( course,  courseDTO);
		System.out.println(" course" + course);
		System.out.println(" course DTO  " +  courseDTO);
		return courseDTO;
	}

	@Override
	public CourseDTO updateCourse(long courseId, CourseDTO courseDTO) {
		System.out.println("in update " + courseDTO);
		// fetch exsiting details from the db
		Course coursedetails= courseRepo.findById(courseId).get();
		System.out.println("coursefrom db " + coursedetails);
		// => userDetails : PERSISTENT POJO
		// copy updated user details coming from request payload ---> User details
		BeanUtils.copyProperties(courseDTO, coursedetails);
		coursedetails.setCourseid(courseId);
		courseDTO.setCourseid(courseId);
		System.out.println("updated course dtls " + coursedetails);
		// modified state of persistent POJO
		return courseDTO;
	}
}

