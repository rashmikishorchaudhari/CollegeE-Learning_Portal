package com.app.Services;

import java.util.List;
import java.util.Optional;

import com.app.dto.DepartmentDTO;
import com.app.pojo.Admin;
import com.app.pojo.AssignClass;
import com.app.pojo.Course;
import com.app.pojo.Department;
import com.app.pojo.Faculty;
import com.app.pojo.Student;
import com.app.pojo.Subject;

public interface DepartmentService {

	
	public List<DepartmentDTO>getAllDepartments();
		
	DepartmentDTO addDepartment(Department department);
	String deleteDepartment(long departmentId);
	DepartmentDTO getDepartment(long departmentId);
	DepartmentDTO updateDepartment(long departmentId,DepartmentDTO departmentDTO);

	

}
