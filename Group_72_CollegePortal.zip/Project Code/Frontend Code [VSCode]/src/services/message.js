import axios from "axios";

const MESSAGE_BASE_URL = "http://localhost:7070/admin/message";
const MESSAGE_BASE_URL2 = "http://localhost:7070/faculty/message";
class messageService {
    getMessages() {
        return axios.get(MESSAGE_BASE_URL);
    }
    getMessages() {
        return axios.get(MESSAGE_BASE_URL2);
    }

    createMessages(txt) {
        return axios.post(MESSAGE_BASE_URL, txt);
    }
    createMessages(txt) {
        return axios.post(MESSAGE_BASE_URL2, txt);
    }
}

export default new messageService;