package com.app.Services;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.app.dto.AdminDTO;
import com.app.dto.AssignClassDTO;
import com.app.dto.CourseDTO;
import com.app.dto.DepartmentDTO;
import com.app.dto.FacultyDTO;
import com.app.dto.SignUpRequest;
import com.app.dto.SubjectDTO;
import com.app.pojo.Admin;
import com.app.pojo.AssignClass;
import com.app.pojo.Course;
import com.app.pojo.Department;
import com.app.pojo.Faculty;
import com.app.pojo.Subject;



public interface AdminService {
	

//AdminDTO addAdminDetails(Admin admin);

//AdminDTO getAdminDetails(long adminId);
//AdminDTO updateAdminDetails(long adminId,AdminDTO adminDTO);
Optional<Admin> getAdminById(Long adminId);
Admin addAdmin(Admin admin);
Admin updateAdmin(long aid, Admin a);
String deleteAdminDetails(long adminId);
//AdminDTO addAdminDetails(Admin admin);
//Object updateDepartment(long departmentId, Department details);
//Admin registeradmin(SignUpRequest request);
//Admin authenticateadmin(String email, String password);




















	
	



	
	



	
	
	

}
