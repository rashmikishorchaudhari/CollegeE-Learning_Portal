import axios from "axios";

const SUBJECT_BASE_URL = "http://localhost:7070/subjects";
class subjectService {
    getSubjects() {
        return axios.get(SUBJECT_BASE_URL);
    }

    createSubject(subj) {
        return axios.post(SUBJECT_BASE_URL, subj);
    }

    getSubjectByID(subjID) {
        return axios.get(SUBJECT_BASE_URL + '/' + subjID);
    }

    updateSubjectByID(subj, subjID) {
        return axios.put(SUBJECT_BASE_URL + '/' + subjID, subj);
    }

    deleteSubjectByID(subjID) {
        return axios.delete(SUBJECT_BASE_URL + '/' + subjID);
    }
}

export default new subjectService;