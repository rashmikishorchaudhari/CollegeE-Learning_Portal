package com.app.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.Services.AdminService;
import com.app.Services.AssignClassService;
import com.app.Services.CourseService;
import com.app.Services.DepartmentService;
import com.app.Services.FacultyService;
import com.app.Services.MessageService;
import com.app.Services.SubjectService;
import com.app.dto.AssignClassDTO;
import com.app.dto.AuthenticationRequest;
import com.app.dto.AuthenticationResponse;
import com.app.dto.CourseDTO;
import com.app.dto.DepartmentDTO;
import com.app.dto.FacultyDTO;
import com.app.dto.ResponseDTO;
import com.app.dto.SignUpRequest;
import com.app.dto.SubjectDTO;
import com.app.pojo.Admin;
import com.app.pojo.AssignClass;
import com.app.pojo.Course;
import com.app.pojo.Department;
import com.app.pojo.Faculty;
import com.app.pojo.Message;
import com.app.pojo.Subject;

@RestController
@RequestMapping("/admin")
@CrossOrigin(origins = "http://localhost:3000")
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	@Autowired 
	private DepartmentService departmentService;
	@Autowired 
	private CourseService courseService;
	@Autowired 
	private FacultyService facultyService;
	@Autowired 
	private AssignClassService assignClassService;
	@Autowired 
	private SubjectService subjectService;
	@Autowired 
	private MessageService messageService;
	
		

	
				// REST request handling method for listing all departments
				@GetMapping("/departments")
				public ResponseEntity<?> getAllDepartments() {
					System.out.println("in get all departments");
					return ResponseEntity.ok(new ResponseDTO<>(departmentService.getAllDepartments()));
				}
				
				// REST request handling method for listing all courses
				@GetMapping("/courses")
				public ResponseEntity<?> getAllCourses() {
					System.out.println("in get all courses");
					return ResponseEntity.ok(new ResponseDTO<>(courseService.getAllCourses()));
				}
				
				// REST request handling method for listing all faculties
				@GetMapping("/faculty")
				public ResponseEntity<?> getAllFaculty() {
					System.out.println("in get all faculties");
					return ResponseEntity.ok(new ResponseDTO<>(facultyService.getAllFaculty()));
				}
				
				// REST request handling method for listing all subjects
				@GetMapping("/subject")
				public ResponseEntity<?> getAllSubjects() {
					System.out.println("in get all subjects");
					return ResponseEntity.ok(new ResponseDTO<>(subjectService.getAllSubjects()));
				}
				
				// REST request handling method for listing all assignclasses
				@GetMapping("/assign_class")
				public ResponseEntity<?> getAllAssignClasses() {
					System.out.println("in get all assignclasses");
					return ResponseEntity.ok(new ResponseDTO<>(assignClassService.getAllAssignClasses()));
				}
				
		//Add Admin methods

				//get admin by Id
				@GetMapping("/admin/{adminId}")
				public Optional<Admin> getAdmin(@PathVariable String adminId) {
					return this .adminService.getAdminById(Long.parseLong(adminId));
				}
				
				//add admin
				@PostMapping("/admin")
				public Admin addAdmin(@RequestBody Admin admin)
				{
					return this.adminService.addAdmin(admin);
				}
							
				//update admin
				@PutMapping("/admin/{adminId}")
				public ResponseEntity<?> updateAdmin(@PathVariable long adminId, @RequestBody Admin details) {
					System.out.println("in update admin " + adminId + " details " + details);
					// invoke service layer's method for product updation
					try {
						return new ResponseEntity<>(adminService.updateAdmin(adminId, details), HttpStatus.OK);
					} catch (RuntimeException e) {
						return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
					}
				}
				
				// REST request handling method to delete admin details
				@DeleteMapping("/admin/{adminId}")
				public ResponseEntity<?> deleteAdminDetails(@PathVariable long adminId) {
					System.out.println("in del admin dtls " + adminId);
					try {
						return ResponseEntity.ok(new ResponseDTO<>(adminService.deleteAdminDetails(adminId)));
					} catch (RuntimeException e) {
						System.out.println("err in delete " + e);
						return new ResponseEntity<>(new ResponseDTO<>("Admin details deletion failed"),
								HttpStatus.INTERNAL_SERVER_ERROR);
					}
				}
				
		//Add department methods
				
				
				// REST request handling method to add a new Department
				@PostMapping("/departments")
				public ResponseEntity<?> addDepartment(@RequestBody Department department) {
					System.out.println("in adddepartment " + department);
					return ResponseEntity.ok(new ResponseDTO<>(departmentService.addDepartment(department)));
				}
		
				// Add REST request handling method to get Department
				@GetMapping("/departments/{departmentId}")
				public ResponseEntity<?> getDepartment(@PathVariable long departmentId) {
					System.out.println("in gt dept " +departmentId);
					return ResponseEntity.ok(new ResponseDTO<>(departmentService.getDepartment(departmentId)));
				}
		
				// REST request handling method to delete departments
				@DeleteMapping("/departments/{departmentId}")
				public ResponseEntity<?> deleteDepartment(@PathVariable long departmentId) {
					System.out.println("in del department " + departmentId);
					try {
						return ResponseEntity.ok(new ResponseDTO<>(departmentService.deleteDepartment(departmentId)));
					} catch (RuntimeException e) {
						System.out.println("err in delete " + e);
						return new ResponseEntity<>(new ResponseDTO<>("Department deletion failed"),
								HttpStatus.INTERNAL_SERVER_ERROR);
					}
				}
				
				
						
				// Add REST request handling method to update departments
				@PutMapping("/departments/{departmentId}")
				public ResponseEntity<?> updateDepartment(@PathVariable long departmentId, @RequestBody DepartmentDTO departmentDTO) {
					System.out.println("in rest : update department " + departmentId + " " + departmentDTO);
					return ResponseEntity.ok(departmentService.updateDepartment(departmentId, departmentDTO));
				}
				
		
				
			//Add Course methods
				
				// REST request handling method to add a new Course
				@PostMapping("/courses")
				public ResponseEntity<?> addCourse(@RequestBody Course course) {
					System.out.println("in addcourse " + course);
					return ResponseEntity.ok(new ResponseDTO<>(courseService.addCourse(course)));
				}
		
				// Add REST request handling method to get Course
				@GetMapping("/courses/{courseId}")
				public ResponseEntity<?> getCourse(@PathVariable long courseId) {
					System.out.println("in get course " +courseId);
					return ResponseEntity.ok(new ResponseDTO<>(courseService.getCourse(courseId)));
				}
		
				// REST request handling method to delete Course
				@DeleteMapping("/courses/{courseId}")
				public ResponseEntity<?> deleteCourse(@PathVariable long courseId) {
					System.out.println("in del course " +courseId);
					try {
						return ResponseEntity.ok(new ResponseDTO<>(courseService.deleteCourse(courseId)));
					} catch (RuntimeException e) {
						System.out.println("err in delete " + e);
						return new ResponseEntity<>(new ResponseDTO<>("Course deletion failed"),
								HttpStatus.INTERNAL_SERVER_ERROR);
					}
				}
					
		
				// Add REST request handling method to update Course
				@PutMapping("/courses/{courseId}")
				public ResponseEntity<?> updateCourse(@PathVariable long courseId, @RequestBody CourseDTO courseDTO) {
					System.out.println("in rest : update course " + courseId + " " + courseDTO);
					return ResponseEntity.ok(courseService.updateCourse(courseId, courseDTO));
				}
				
		
		//Add faculty methods
						
				// REST request handling method to add a new Faculty
				@PostMapping("/faculty")
				public ResponseEntity<?> addFaculty(@RequestBody Faculty faculty) {
					System.out.println("in add faculty " + faculty);
					return ResponseEntity.ok(new ResponseDTO<>(facultyService.addFaculty(faculty)));
				}
		
		
				// REST request handling method to delete faculty
				@DeleteMapping("/faculty/{facultyId}")
				public ResponseEntity<?> deleteFaculty(@PathVariable long facultyId) {
					System.out.println("in del faculty " + facultyId);
					try {
						return ResponseEntity.ok(new ResponseDTO<>(facultyService.deleteFaculty(facultyId)));
					} catch (RuntimeException e) {
						System.out.println("err in delete " + e);
						return new ResponseEntity<>(new ResponseDTO<>("Faculty deletion failed"),
								HttpStatus.INTERNAL_SERVER_ERROR);
					}
				}
		
				// Add REST request handling method to get faculty
				@GetMapping("/faculty/{facultyId}")
				public ResponseEntity<?> getFaculty(@PathVariable long facultyId) {
					System.out.println("in get faculty " +facultyId);
					return ResponseEntity.ok(new ResponseDTO<>(facultyService.getFaculty(facultyId)));
				}
		
				// Add REST request handling method to update faculty
				@PutMapping("/faculty/{facultyId}")
				public ResponseEntity<?> updateFaculty(@PathVariable long facultyId, @RequestBody FacultyDTO facultyDTO) {
					System.out.println("in rest : update faculty " + facultyId + " " + facultyDTO);
					return ResponseEntity.ok(facultyService.updateFaculty(facultyId, facultyDTO));
				}
		
	 //Add Subject methods
		
				// REST request handling method to add a new Subject
				@PostMapping("/subject")
				public ResponseEntity<?> addSubject(@RequestBody Subject subject) {
					System.out.println("in add subject " + subject);
					return ResponseEntity.ok(new ResponseDTO<>(subjectService.addSubject(subject)));
				}
		
		
				// REST request handling method to delete subject
				@DeleteMapping("/subject/{subjectId}")
				public ResponseEntity<?> deleteSubject(@PathVariable long subjectId) {
					System.out.println("in del subject " +subjectId);
					try {
						return ResponseEntity.ok(new ResponseDTO<>(subjectService.deleteSubject(subjectId)));
					} catch (RuntimeException e) {
						System.out.println("err in delete " + e);
						return new ResponseEntity<>(new ResponseDTO<>("Subject deletion failed"),
								HttpStatus.INTERNAL_SERVER_ERROR);
					}
				}
		
				// Add REST request handling method to get subject
				@GetMapping("/subject/{subjectId}")
				public ResponseEntity<?> getSubject(@PathVariable long subjectId) {
					System.out.println("in get subject " +subjectId);
					return ResponseEntity.ok(new ResponseDTO<>(subjectService.getSubject(subjectId)));
				}
		
				// Add REST request handling method to update faculty
				@PutMapping("/subject/{subjectId}")
				public ResponseEntity<?> updateSubject(@PathVariable long subjectId, @RequestBody SubjectDTO subjectDTO) {
					System.out.println("in rest : update subject " + subjectId + " " + subjectDTO);
					return ResponseEntity.ok(subjectService.updateSubject(subjectId, subjectDTO));
				}
		
	//Add AssignClass methods
				
				// REST request handling method to add a new AssignClass
				@PostMapping("/assign_class")
				public ResponseEntity<?> addAssignClass(@RequestBody AssignClass assignClass) {
					System.out.println("in add assignClass " + assignClass);
					return ResponseEntity.ok(new ResponseDTO<>(assignClassService.addAssignClass(assignClass)));
				}
		
		
				// REST request handling method to delete AssignClass
				@DeleteMapping("/assign_class/{assignClassId}")
				public ResponseEntity<?> deleteAssignClass(@PathVariable long assignClassId) {
					System.out.println("in del assignClass " +assignClassId);
					try {
						return ResponseEntity.ok(new ResponseDTO<>(assignClassService.deleteAssignClass(assignClassId)));
					} catch (RuntimeException e) {
						System.out.println("err in delete " + e);
						return new ResponseEntity<>(new ResponseDTO<>("AssignClass deletion failed"),
								HttpStatus.INTERNAL_SERVER_ERROR);
					}
				}
		
				// Add REST request handling method to get assignClass
				@GetMapping("/assign_class/{assignClassId}")
				public ResponseEntity<?> getAssignClass(@PathVariable long assignClassId) {
					System.out.println("in getassignClass " +assignClassId);
					return ResponseEntity.ok(new ResponseDTO<>(assignClassService.getAssignClass(assignClassId)));
				}
		
				// Add REST request handling method to update assignClass
				@PutMapping("/assign_class/{assignClassId}")
				public ResponseEntity<?> updateAssignClass(@PathVariable long assignClassId, @RequestBody AssignClassDTO assignClassDTO) {
					System.out.println("in rest : update assignClass" + assignClassId + " " + assignClassDTO);
					return ResponseEntity.ok(assignClassService.updateAssignClass(assignClassId, assignClassDTO));
				}
				
//				
//				@PostMapping("/DepartmentList")
//				public ResponseEntity<?> findAvailableCourses(@RequestBody CourseDTO courseDTO ){
//					try {
//						//System.out.println(" inc cpntroller method with data: "+venuerequestDTO);
//						List<Course> bookedVenues=custService.getAvailableVenues(LocalDate.parse(venuerequestDTO.getSdate()), LocalDate.parse(venuerequestDTO.getEdate()), VenuePackage.valueOf(venuerequestDTO.getVenuePackage()));
//						System.out.println(" Booked venue  : "+bookedVenues);
//						List<Venue> allVenues=venueDao.findByVenuePackageAndEvents_EventName(VenuePackage.valueOf(venuerequestDTO.getVenuePackage()),EventName.valueOf(venuerequestDTO.getEventName()));
//						System.out.println(" All venues with package and event name : "+allVenues);
//						//List<Venue> allVenuesByEvent=venueDao.findByEvents_EventName(EventName.valueOf(venuerequestDTO.getEventName()));
//						//System.out.println(" All venue by event list :"+allVenuesByEvent);
//						System.out.println("removed or not : "+allVenues.removeAll(bookedVenues));
//						System.out.println("after filtering available venues: "+allVenues);
//						return new ResponseEntity<>(allVenues, HttpStatus.OK);
//					} catch (Exception e) {
//						System.out.println(" in controller catch ");
//						e.printStackTrace();
//						return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
//					}
//				}
				
				
	//Message
				// REST request handling method to add a new Message
				@PostMapping("/message")
				public ResponseEntity<?> addMessage(@RequestBody Message message) {
					System.out.println("in add message " + message);
					return ResponseEntity.ok(new ResponseDTO<>(messageService.addMessage(message)));
				}
				
				// REST request handling method for listing all departments
				@GetMapping("/message")
				public ResponseEntity<?> getAllMessages() {
					System.out.println("in get all messages");
					return ResponseEntity.ok(new ResponseDTO<>(messageService.getAllMessage()));
				}
				
				// REST request handling method to delete admin details
				@DeleteMapping("/message/{messageId}")
				public ResponseEntity<?> deleteMessagedetails(@PathVariable long messageId) {
					System.out.println("in del message dtls " + messageId);
					try {
						return ResponseEntity.ok(new ResponseDTO<>(messageService.deleteMessagedetails(messageId)));
					} catch (RuntimeException e) {
						System.out.println("err in delete " + e);
						return new ResponseEntity<>(new ResponseDTO<>("Message details deletion failed"),
								HttpStatus.INTERNAL_SERVER_ERROR);
					}
				}
}
		
						

