import axios from "axios";

const STUDENT_INFO_BASE_URL="http://localhost:7070/student";
class studentService{
    getStudents(){
        return axios.get(STUDENT_INFO_BASE_URL);
    }

    createStudent(){
        return axios.post(STUDENT_INFO_BASE_URL +'/signup');
    }
}

export default new studentService;