package com.app.dto;



public class CourseDTO {
	private  long courseid;
	private String name;
	private String pattern;
	private String duration;
	private String fees;
	private String departmentName;
	public CourseDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
//	public CourseDTO(long courseid, String name, String pattern, String duration, String fees) {
//		super();
//		this.courseid = courseid;
//		this.name = name;
//		this.pattern = pattern;
//		this.duration = duration;
//		this.fees = fees;
//	}
	/**
	 * @return the courseid
	 */
	public long getCourseid() {
		return courseid;
	}
	/**
	 * @param courseid the courseid to set
	 */
	public void setCourseid(long courseid) {
		this.courseid = courseid;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the pattern
	 */
	public String getPattern() {
		return pattern;
	}
	/**
	 * @param pattern the pattern to set
	 */
	public void setPattern(String pattern) {
		this.pattern = pattern;
	}
	/**
	 * @return the duration
	 */
	public String getDuration() {
		return duration;
	}
	/**
	 * @param duration the duration to set
	 */
	public void setDuration(String duration) {
		this.duration = duration;
	}
	/**
	 * @return the fees
	 */
	public String getFees() {
		return fees;
	}
	/**
	 * @param fees the fees to set
	 */
	public void setFees(String fees) {
		this.fees = fees;
	}
	
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	@Override
	public String toString() {
		return "CourseDTO [courseid=" + courseid + ", name=" + name + ", pattern=" + pattern + ", duration=" + duration
				+ ", fees=" + fees + ", departmentName=" + departmentName + "]";
	}
	
	
	

}
