package com.app.pojo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Shared_files")
public class SharedFiles {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="shared_file_id")
	private long id;
    //@Enumerated(EnumType.STRING)
    @Column(length = 50)
    private String type;
    @Column(length = 50)
	private String comment;
    @Lob
    private byte[] data;
    private String name;
	
	@ManyToOne
	@JoinColumn(name="c_id",nullable=false)
	private Course chosencourse;
	
	@ManyToOne
	@JoinColumn(name="sub_id",nullable=false)
	private Subject chosenSubject;

		

	public SharedFiles(long id, String type, String comment, byte[] data, String name, Course chosencourse,
			Subject chosenSubject) {
		super();
		this.id = id;
		this.type = type;
		this.comment = comment;
		this.data = data;
		this.name = name;
		this.chosencourse = chosencourse;
		this.chosenSubject = chosenSubject;
	}


	public SharedFiles(String fileName, String string, byte[] bs) {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public String getComment() {
		return comment;
	}


	public void setComment(String comment) {
		this.comment = comment;
	}


	public byte[] getData() {
		return data;
	}


	public void setData(byte[] data) {
		this.data = data;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Course getChosencourse() {
		return chosencourse;
	}


	public void setChosencourse(Course chosencourse) {
		this.chosencourse = chosencourse;
	}


	public Subject getChosenSubject() {
		return chosenSubject;
	}


	public void setChosenSubject(Subject chosenSubject) {
		this.chosenSubject = chosenSubject;
	}


	@Override
	public String toString() {
		return "SharedFiles [id=" + id + ", type=" + type + ", comment=" + comment + ", data=" + Arrays.toString(data)
				+ ", name=" + name + ", chosencourse=" + chosencourse + ", chosenSubject=" + chosenSubject + "]";
	}
	
	
}
