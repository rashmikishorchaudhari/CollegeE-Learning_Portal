package com.app.pojo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "faculty")
public class Faculty {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "faculty_id")
	private long facultyid;
	@Column(name = "faculty_name",length = 50)
	private String name;
	@Column(length = 50)
	private String email;
	@Column(nullable = false)
	private String Password;
	@Column(name="contact_no",length = 50)
	private String contactno;
	@Column(length = 50)
	private String Specialization;
	@Column(length = 50)
	private String Username;
	

	@OneToMany(mappedBy = "chosenFaculty",cascade = CascadeType.ALL,orphanRemoval = true)
	private List<AssignClass>assignclass;
	
	@ManyToOne
	@JoinColumn(name="d_id",nullable=false)
	private Department chosenDepartment;
	
//	@ManyToOne
//	@JoinColumn(name="c_id",nullable=false)
//	private Course chosenCourse;
	
	private boolean active;
	//uni dir many-to-many from User *<----->*
	@ManyToMany
	@JoinTable(name = "user_roles", 
	joinColumns = @JoinColumn(name = "user_id"), 
	inverseJoinColumns = @JoinColumn(name = "role_id"))
	private Set<Role> roles = new HashSet<>();
	
	
	
	public Faculty() {
		super();
		// TODO Auto-generated constructor stub
	}


	

	public Faculty(long facultyid, String name, String email, String password, String contactno, String specialization,
		String username, Department chosenDepartment, List<AssignClass> assignclass) {
	super();
	this.facultyid = facultyid;
	this.name = name;
	this.email = email;
	Password = password;
	this.contactno = contactno;
	Specialization = specialization;
	Username = username;
	this.chosenDepartment = chosenDepartment;
	//this.chosenCourse = chosenCourse;
	this.assignclass = assignclass;
}

	public long getId() {
		return facultyid;
	}




	public void setId(long id) {
		this.facultyid = id;
	}




	public String getName() {
		return name;
	}




	public void setName(String name) {
		this.name = name;
	}




	public String getEmail() {
		return email;
	}




	public void setEmail(String email) {
		this.email = email;
	}




	public String getPassword() {
		return Password;
	}




	public void setPassword(String password) {
		Password = password;
	}




	public String getContactno() {
		return contactno;
	}




	public void setContactno(String contactno) {
		this.contactno = contactno;
	}




	public String getSpecialization() {
		return Specialization;
	}




	public void setSpecialization(String specialization) {
		Specialization = specialization;
	}




	public String getUsername() {
		return Username;
	}




	public void setUsername(String username) {
		Username = username;
	}




	public List<AssignClass> getAssignclass() {
		return assignclass;
	}




	public void setAssignclass(List<AssignClass> assignclass) {
		this.assignclass = assignclass;
	}




	public Department getChosenDepartment() {
		return chosenDepartment;
	}




	public void setChosenDepartment(Department chosenDepartment) {
		this.chosenDepartment = chosenDepartment;
	}



//
//	public Course getChosenCourse() {
//		return chosenCourse;
//	}
//
//
//
//
//	public void setChosenCourse(Course chosenCourse) {
//		this.chosenCourse = chosenCourse;
//	}




	public long getFacultyid() {
		return facultyid;
	}




	public void setFacultyid(long facultyid) {
		this.facultyid = facultyid;
	}




	public boolean isActive() {
		return active;
	}




	public void setActive(boolean active) {
		this.active = active;
	}




	public Set<Role> getRoles() {
		return roles;
	}




	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}




	@Override
	public String toString() {
		return "Faculty [id=" + facultyid + ", name=" + name + ", email=" + email + ", Password=" + Password + ", contactno="
				+ contactno + ", Specialization=" + Specialization + "]";
	}
	
	//helper methods to add n remove assignclass
	public void addAssignClass(AssignClass as)
	{
		assignclass.add(as);
		as.setChosenFaculty(this);
	}
	public void removeAssignClass(AssignClass as)
	{
		assignclass.remove(as);
		as.setChosenFaculty(null);
	}




}
