import React, { Fragment, Component } from "react";
import { Form, FormGroup, Label, Input, Container, Button, Col, Row, Table } from "reactstrap";
import assignClassService from "../../services/assign_class";

class assign_class extends Component {

    constructor(props) {
        super(props);

        this.state = {
            
                assign_classes:[]
        }

    }

    //TO GET ALL ASSIGN_CLASSES:-  
    componentDidMount() {
       assignClassService.getClasses().then((res) => {
           this.setState({assign_classes: res.data});
       })
     }
     
    render() {
        return (
            <Fragment>
            <Row>
                <Col md={1}>
                </Col>
                <Col className="m-3" md={8}>
                    <Form>
                        <h3 className="bg-info p-2 text-center" style={{ color: "white" }}>Assign Class to Faculty</h3>
                        <Row form>
                            <Col md={6}>
                                <FormGroup>
                                    <Label for="">Select Department</Label>
                                    <Input type="select" name="department" id="">
                                        <option>Diploma</option>
                                        <option>Engineering</option>
                                        <option>Management</option>
                                        <option>Computer</option>
                                        <option>11th / 12th</option>
                                    </Input>
                                </FormGroup>
                            </Col>
                            <Col md={6}>
                                <FormGroup>
                                    <Label for="">Select Courses</Label>
                                    <Input type="select" name="courses" id="">
                                        <option>B.E</option>
                                        <option>M.E</option>
                                        <option>BBA</option>
                                        <option>MBA</option>
                                        <option>MCA</option>
                                    </Input>
                                </FormGroup>
                            </Col>
                        </Row>
                        <Row form>
                            <Col md={6}>
                                <FormGroup>
                                    <Label for="">Select Subjects</Label>
                                    <Input type="select" name="subjects" id="">
                                        <option>Java</option>
                                        <option>Human Resource Management</option>
                                        <option>Accounts</option>
                                        <option>Advance Java</option>

                                    </Input>
                                </FormGroup>
                            </Col>
                            <Col md={6}>
                                <FormGroup>
                                    <Label for="">Select Faculty</Label>
                                    <Input type="select" name="faculty" id="">
                                        <option>Ram</option>
                                        <option>Raju</option>
                                        <option>Balram</option>
                                        <option>Chinky</option>
                                        <option>Pinky</option>
                                    </Input>
                                </FormGroup>
                            </Col>
                        </Row>


                        <Container className="text-center" >
                            <Button type="submit" color="success">Assign</Button>
                            <Button type="reset" color="danger ml-2">Reset</Button>
                        </Container>
                    </Form>
                </Col>
            </Row>

            <Row>
                <Col md={1}>
                </Col>
                <Col className="m-3" md={8}>
                    <h3 className="bg-info p-2 text-center" style={{ color: "white" }}>Edit-Details</h3>

                    <Table className="text-center" striped hover bordered size="sm">
                        <thead>
                            <tr>
                               
                                <th>Name</th>
                                <th>Course</th>
                                <th>Subject</th>
                                <th>View</th>
                                <th>Edit</th>
                                <th>Delete</th>

                            </tr>
                        </thead>
                        <tbody>
                        {
                                    this.state.assign_classes.map(
                                        assign_class =>
                                            <tr key={assign_class.id}>
                                                <td>{assign_class.f_id}</td>
                                                <td>{assign_class.c_id}</td>
                                                <td>{assign_class.d_id}</td>
                                                <td>{assign_class.sub_id}</td>

                                            </tr>

                                    )
                                }
                           
                        </tbody>
                    </Table>
                </Col>
            </Row>
        </Fragment>
        );
    }
}

export default assign_class;
  