import axios from "axios";

const ASSIGN_CLASS_BASE_URL = "http://localhost:7070/assign_class";
class assignClassService {
    getClasses() {
        return axios.get(ASSIGN_CLASS_BASE_URL);
    }

    createClass(cls) {
        return axios.post(ASSIGN_CLASS_BASE_URL, cls);
    }

    getClassByID(clsID) {
        return axios.get(ASSIGN_CLASS_BASE_URL + '/' + clsID);
    }

    updateClassByID(cls, clsID) {
        return axios.put(ASSIGN_CLASS_BASE_URL + '/' + clsID, cls);
    }

    deleteClassByID(clsID) {
        return axios.delete(ASSIGN_CLASS_BASE_URL + '/' + clsID);
    }
}

export default new assignClassService;