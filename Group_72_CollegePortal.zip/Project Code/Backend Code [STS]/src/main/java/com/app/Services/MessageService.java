package com.app.Services;

import java.util.List;

import com.app.dto.MessageDTO;
import com.app.pojo.Message;

public interface MessageService {

	Message addMessage(Message message);

	List<MessageDTO> getAllMessage();

	String deleteMessagedetails(long messageId);

}
