import React, {Component } from "react";
// import { Link } from "react-router-dom";
// import { ListGroup } from "reactstrap";
import Carousel from "react-bootstrap/Carousel";
import img1 from "../images/slide1.jpg";
import img2 from "../images/slide2.jpg";
import img3 from "../images/slide3.jpg";


class home_menu extends Component {
    render() {
        return (
           
              
            <Carousel fade="true" interval="1500" className="mt-2 mr-3" style={{border:"0px solid grey",}}>
                <Carousel.Item>
                <img className="d-block" style={{width:"100%",height:"62vh"}} src={img1} />
                <Carousel.Caption>
                <h3>ABC</h3>
                </Carousel.Caption>
                </Carousel.Item>

                <Carousel.Item>
                <img className="d-block" style={{width:"100%",height:"62vh"}} src={img2} />
                <Carousel.Caption>
                <h3>ABC</h3>
                </Carousel.Caption>
                </Carousel.Item>

                <Carousel.Item>
                <img className="d-block" style={{width:"100%",height:"62vh"}} src={img3} />
                <Carousel.Caption>
                <h3>ABC</h3>
                </Carousel.Caption>
                </Carousel.Item>
                
            </Carousel>
       
           
        );
    }
}

export default home_menu;
   