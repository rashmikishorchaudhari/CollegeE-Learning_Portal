package com.app.pojo;

public enum DocumentDescription {
Adharcard,DegreeCertificate,HSCMarksheet,SSCMarksheet
}
