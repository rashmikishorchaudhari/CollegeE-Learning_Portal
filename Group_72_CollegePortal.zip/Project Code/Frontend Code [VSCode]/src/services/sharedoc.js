import axios from "axios";

const SHARE_DOCS_BASE_URL = "http://localhost:7070/faculty/files";
class docsService {
    getFiles() {
        return axios.get(SHARE_DOCS_BASE_URL);
    }

    createDeparment(fd) {
        return axios.post(SHARE_DOCS_BASE_URL, fd);
    }

    deleteFileByID(fdID) {
        return axios.delete(SHARE_DOCS_BASE_URL + '/' + fdID);
    }
}

export default new docsService;