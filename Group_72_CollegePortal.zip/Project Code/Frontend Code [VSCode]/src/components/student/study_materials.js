import React, { Fragment, useEffect, useState, Component } from "react";
import { Link } from "react-router-dom";
import { Form, FormGroup, Label, Input, Container, Button, Col, Row, Table } from "reactstrap";
import DescriptionIcon from '@material-ui/icons/Description';

class study_materials extends Component {

    constructor(props) {
        super(props);

        this.state = {
        
        }

    }

    render() {
        return (
            <Fragment>
            <Row className="m-1">
                <Col md={1}></Col>
                <Col md={8}>
                    <h3 style={{ color: "white" }} className="p-2 text-center bg-info">Study Point</h3>
                </Col>
            </Row>

            <Row>

                <Col md={1}></Col>
                <Col md={2} style={{ border: "2px solid #dedddc", textDecoration: "none" }} className="p-3 text-center">

                    <Link to="/student/notes" action>

                        <Row>
                            <Col>
                                <DescriptionIcon color="action" style={{ opacity: "0.3", fontSize: 110 }} />
                            </Col>
                        </Row>
                        <Row>
                            <Col>
                                <Label style={{ color: "grey" }}>Notes</Label>
                            </Col>
                        </Row>

                    </Link>
                </Col>

                <Col md={2} style={{ border: "2px solid #dedddc", textDecoration: "none" }} className="p-3 text-center">
                    <Link to="/student/assignment" action>
                        <Row>
                            <Col>
                                <DescriptionIcon color="action" style={{ opacity: "0.3", fontSize: 110 }} />
                            </Col>
                        </Row>
                        <Row>
                            <Col>
                                <Label style={{ color: "grey" }}>Assignment</Label>
                            </Col>
                        </Row>
                    </Link>
                </Col>

                <Col md={2} style={{ border: "2px solid #dedddc", textDecoration: "none" }} className="p-3 text-center">

                    <Link to="/student/question_bank" action>
                        <Row>
                            <Col>
                                <DescriptionIcon color="action" style={{ opacity: "0.3", fontSize: 110 }} />
                            </Col>
                        </Row>
                        <Row>
                            <Col>
                                <Label style={{ color: "grey" }}>Question Bank</Label>
                            </Col>
                        </Row>
                    </Link>
                </Col>

                <Col md={2} style={{ border: "2px solid #dedddc", textDecoration: "none" }} className="p-3 text-center">
                    <Link to="/student/syllabus" action>
                        <Row>
                            <Col>
                                <DescriptionIcon color="action" style={{ opacity: "0.3", fontSize: 110 }} />
                            </Col>
                        </Row>
                        <Row>
                            <Col>
                                <Label style={{ color: "grey" }}>Syllabus</Label>
                            </Col>
                        </Row>
                    </Link>
                </Col>

            </Row>

        </Fragment>
        );
    }
}

export default study_materials;
        