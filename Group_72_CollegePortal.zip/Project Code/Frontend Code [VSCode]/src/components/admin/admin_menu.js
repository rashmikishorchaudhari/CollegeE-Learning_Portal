import React, {Component } from "react";
import { Link } from "react-router-dom";
import { ListGroup } from "reactstrap";

class admin_menu extends Component {
    render() {
        return (
            <ListGroup>
            <Link className="text-center list-group-item list-group-item-action" to="/admin/add_faculty" action>Add Faculty</Link>
            <Link className="text-center list-group-item list-group-item-action" to="/admin/add_dept" action>Add Department</Link>
            <Link className="text-center list-group-item list-group-item-action" to="/admin/add_course" action>Add Courses</Link>
            <Link className="text-center list-group-item list-group-item-action" to="/admin/add_subject" action>Add Subjects</Link>
            <Link className="text-center list-group-item list-group-item-action" to="/admin/assign_class" action>Assign Class</Link>
            <Link className="text-center list-group-item list-group-item-action" to="/admin/set_feedback" action>Set Feedbacks</Link>

            </ListGroup>
        );
    }
}

export default admin_menu;
   